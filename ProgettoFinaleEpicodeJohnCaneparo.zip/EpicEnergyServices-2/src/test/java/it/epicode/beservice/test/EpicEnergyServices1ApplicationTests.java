package it.epicode.beservice.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpicEnergyServices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
