package it.epicode.beservice.model;

public enum RoleType {
	ROLE_USER, ROLE_ADMIN;
}
