package it.epicode.beservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpicEnergyServices1Application {

	public static void main(String[] args) {
		SpringApplication.run(EpicEnergyServices1Application.class, args);
		System.out.println();
		System.out.println();
		System.out.println("----------------------------");
	}

}
