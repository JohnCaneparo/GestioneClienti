package it.epicode.beservice.model;

public enum TipoCliente {
	SRL, SPA, SAS, PA;
}
